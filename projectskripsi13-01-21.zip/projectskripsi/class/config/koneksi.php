<?php
/*
 * Configuration Database
 */
return array(
    'host' => "localhost",
    'username' => "root",
    'password' => "",
    'dbname' => "db_klasifikasi",
);

?>
