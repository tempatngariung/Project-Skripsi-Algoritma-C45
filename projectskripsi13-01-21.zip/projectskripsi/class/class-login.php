<?php 

    class DataUser{
        public $username;
        public $password;

        function set_value($username,$password){
            $this->username = $username;
            $this->password = $password;
        }

        function get_username(){
            return $this->username;
        }
        function get_password(){
            return $this->password;
        }
    }
       
?>