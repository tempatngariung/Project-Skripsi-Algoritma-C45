<?php 

    class DataSiswa{
        public $nisn;
        public $nama;
        public $jenis_kelamin;
        public $asal_sekolah;
        public $status_sekolah;
        public $kota_asal;
        public $registrasi;

        function set_value($nisn,$nama,$jenis_kelamin,$asal_sekolah,$status_sekolah,$kota_asal,$registrasi){
            $this->nisn = $nisn;
            $this->nama = $nama;
            $this->jenis_kelamin = $jenis_kelamin;
            $this->asal_sekolah = $asal_sekolah;
            $this->status_sekolah = $status_sekolah;
            $this->kota_asal = $kota_asal;
            $this->registrasi = $registrasi;
        }

        function get_nisn(){
            return $this->nisn;
        }
        function get_nama(){
            return $this->nama;
        }
        function get_jenis_kelamin(){
            return $this->jenis_kelamin;
        }
        function get_asal_sekolah(){
            return $this->asal_sekolah;
        }
        function get_status_sekolah(){
            return $this->status_sekolah;
        }
        function get_kota_asal(){
            return $this->kota_asal;
        }
        function get_registrasi(){
            return $this->registrasi;
        }
    }
       
?>