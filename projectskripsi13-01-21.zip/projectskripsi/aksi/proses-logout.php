<?php

session_start();
if (isset($_SESSION['level_user'])) {
    session_unset();
    header("location:../?");
}else{
    header("location:../?");
}

?>
