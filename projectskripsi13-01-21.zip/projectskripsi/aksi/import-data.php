<?php 
session_start();

include '../class/config/koneksi.php';
include '../class/class-data-siswa.php';
include '../class/class-database.php';
include '../plugin/excel_reader3.php';

if (!isset($_SESSION['level_user'])) {
  echo "
    <script>
      location.replace('../?');
    </script>
  ";
}else{

$data_siswa = new DataSiswa();

$db_object = new database();

$target = basename($_FILES['dokumen']['name']) ;

if ($target != '') {

    $db_object->db_query("TRUNCATE tbl_data_latih");
    
    move_uploaded_file($_FILES['dokumen']['tmp_name'], $target);

    chmod($_FILES['dokumen']['name'],0777);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['dokumen']['name'],false);
    $jumlah_baris = $data->rowcount($sheet_index=0);
    
    $berhasil = 0;
    for ($i=2; $i<=$jumlah_baris; $i++){
    
        $data_siswa->set_value($data->val($i, 1),$data->val($i, 2),$data->val($i, 3),$data->val($i, 4),$data->val($i, 5),$data->val($i, 6),$data->val($i, 7));
    
        $value = "INSERT INTO `tbl_data_latih`(`nisn`, `nama`, `jenis_kelamin`, `asal_sekolah`, `status_sekolah`, `kota_asal`, `registrasi`) VALUES ('$data_siswa->nisn','$data_siswa->nama','$data_siswa->jenis_kelamin','$data_siswa->asal_sekolah','$data_siswa->status_sekolah','$data_siswa->kota_asal','$data_siswa->registrasi')";
        
        $db_object->db_query($value);
    }
    unlink($_FILES['dokumen']['name']);
    echo "
        <script>
            alert('import berhasil');
            location.replace('../user-admin/?olah_data');
        </script>
    ";
}else{
    echo "
        <script>
            alert('import tidak berhasil');
            location.replace('../user-admin/?olah_data');
        </script>
    ";
}

}
?>