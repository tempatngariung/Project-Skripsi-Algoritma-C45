<?php

session_start();

include '../class/class-database.php';
include '../class/class-login.php';

$data_user = new DataUser();
$db_object = new database();


if (!isset($_POST['username']) && !isset($_POST['password'])) {
    header("location:../");
}else{

    $data_user->set_value(strip_tags(trim($_POST['username'])),md5(strip_tags(trim($_POST['password']))));
    $sql = "SELECT * FROM `tbl_user` WHERE `username` = '$data_user->username' AND `password` = '$data_user->password'";
    
    if ($db_object->db_num_rows($db_object->db_query($sql)) > 0) {
        $rows = $db_object->db_fetch_array($db_object->db_query($sql));
        unset($_POST);        
        if ($rows['level'] == 'admin') {
            $_SESSION['level_user'] = $rows['level'];
            header("location:../user-admin/?");
        }else{
            $_SESSION['level_user'] = $rows['level'];
            header("location:../user-kepsek/?");
        }
    } else {
        echo "
            <script>
                alert('Username atau password salah');
                location.replace('../?');
            </script>
        ";
    }    
}

?>
