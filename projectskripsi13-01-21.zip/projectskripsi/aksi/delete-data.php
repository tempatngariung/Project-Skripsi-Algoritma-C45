<?php 

include '../class/config/koneksi.php';
include '../class/class-database.php';

session_start();

if (!isset($_SESSION['level_user'])) {
    echo "
      <script>
        location.replace('../?');
      </script>
    ";
}else{

$db_object = new database();
$db_object->db_query("TRUNCATE tbl_data_latih");
echo "
    <script>
        alert('delete berhasil');
        location.replace('../user-admin/?olah_data');
    </script>
";

}
?>