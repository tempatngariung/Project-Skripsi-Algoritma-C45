<?php 
session_start();

if (isset($_SESSION['level_user'])) {
    $level = $_SESSION['level_user'];
    if ($level == 'admin') {
        header("location:user-admin/?");
    }else{
        header("location:user-kepsek/?");
    }
}else{

?>
<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width,initial-scale=1.0" />
		<title>Aplikasi Klasifikasi</title>
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link rel="stylesheet" href="css/style.css"/>
		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/bootstrap.js"></script>
        <script type="text/javascript">
			$("#modal-login").modal("show");
		</script>
        <style type="text/css">
        .style2 {
            font-family: "Times New Roman", Times, serif;
            font-size: 16px;
        }
        .style7 {
            font-size: 16px;
            font-family: "Trebuchet MS";
        }
        </style>
</head>
<body>
		
		
<p align="center">
    <img src="img/foto.jpg" alt="" width="90%" height="300px">
</p>

<div class="container" style="width: 92%;">
    <nav class="navbar navbar-inverse" style="background: #d9edf7; border: none;">
        <div class="container-fluid" style="color: rgb(73, 160, 250);">
            <form action="" method="GET">
                <button class="btn navbar-btn" style="background: none; outline: none;" type="submit" name="">Home</button>
                <button class="btn navbar-btn" style="background: none; outline: none;" type="submit" name="profile">Profile</button>		
                <button class="btn navbar-btn" style="background: none; outline: none;" type="button" data-toggle="modal" data-target="#myModal">Login</button>
            </form>
        </div>
    </nav>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
<div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Login</h4>
    </div>
    <div class="modal-body">

    <form action="aksi/proses-login.php" method="POST">
        <div class="form-group">
        <label for="username">Username :</label>
        <input type="username" class="form-control" id="username" placeholder="Enter username" name="username" required>
        </div>
        <div class="form-group">
        <label for="password">Password :</label>
        <input type="password" class="form-control" id="password" placeholder="Enter password" name="password" required>
        </div>
        <button type="submit" class="btn btn-default">Login</button>
    </form>

    </div>
    </div>
    
</div>
</div>

<div class="page">
    <div class="row">
        <div class="col-sm-9">	
            <div >
                <span class="style7">
                    <?php
        
                        if (!isset($_GET['profile'])) {
                            echo "
                                <p class='text-justify'>aplikasi klasifikasi adalah aplikasi pengolaan data yang menggunakan salah satu teknik pendekatan data mining yaitu algoritma c4.5. Dimana aplikasi ini dapat mengolah data yang hasilnya membentuk klasifikasi dan pohon keputusan yang bertujuan untuk membantu tim promosi dalam strategi promosi Madrasah Aliyah Hidayatulloh</p>
                            ";
                        }else if(isset($_GET['profile'])){
                            echo "
                                <p class='text-justify'></p>
                            ";
                        }

                    ?> 
                </span> 
            </div>
        </div>
        <div class="col-sm-3 blog-sidebar">	
            <div class="sidebar-module">
                <?php		
                    include "sidebar.php";
                ?>
            </div>
        </div>
    </div>
</div>

<div class="panel-footer">
    <h6>&copy 2020 All Right Reserved</h6>
</div>
		
</body>
</html>
 <script defer src="js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

<script>

$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});
</script>

<?php 
}
?>