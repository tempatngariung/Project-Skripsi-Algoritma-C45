<?php 
  
  session_start();
  if (!isset($_SESSION['level_user'])) {
    echo "
      <script>
        alert('Mohon login dahulu...');
        location.replace('../?');
      </script>
    ";
  }elseif (isset($_SESSION['level_user'])) {
    $level = $_SESSION['level_user'];
    if ($level != 'kepsek') {
      header("location:../?");
    }else{

  include '../class/config/koneksi.php';
  include '../class/class-data-siswa.php';
  include '../class/class-database.php';
  
  $data_siswa = new DataSiswa();
  $db_object = new database();

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin | MA Hidayatulloh</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <style>
    .row.content {height: 550px}
    .sidenav {
      height: 100%;
    }
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 
    }
    .fileUpload {
    position: relative;
    overflow: hidden;
    margin: 10px;
    }
    .fileUpload input.upload {
        position: absolute;
        top: 0;
        right: 0;
        margin: 0;
        padding: 0;
        font-size: 20px;
        cursor: pointer;
        opacity: 0;
        filter: alpha(opacity=0);
    }
  </style>
  <script>
    document.getElementById("uploadBtn").onchange = function () {
        document.getElementById("uploadFile").value = this.value;
    };  
  </script>
</head>
<body>

<nav class="navbar navbar-inverse visible-xs">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="?">Home</a></li>
        <li><a href="?pohon_keputusan=">Pohon keputusan</a></li>
        <li><a href="?hasil=">Hasil</a></li>
        <li><a href="../aksi/proses-logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid">
  <div class="row content">

    <div class="col-sm-3 sidenav hidden-xs"><br>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="?">Home</a></li>
        <li><a href="?pohon_keputusan=">Pohon keputusan</a></li>
        <li><a href="?hasil=">Hasil</a></li>
        <li><a href="../aksi/proses-logout.php">Logout</a></li>
      </ul><br>
    </div>
    <br>
    
    <div class="col-sm-9">
      <div class="well">

        <?php 
          if (!isset($_GET['pohon_keputusan']) && !isset($_GET['hasil'])) {            
        ?>

            <div class="row">
              <div class="col-sm-8">
                <p class="text-center">
                  <img src="../img/foto.jpg" alt="" width="100%" height="300px">
                </p>
              </div>
              <div class="col-sm-4">
                <p class='text-justify'>aplikasi klasifikasi adalah aplikasi pengolaan data yang menggunakan salah satu teknik pendekatan data mining yaitu algoritma c4.5. Dimana aplikasi ini dapat mengolah data yang hasilnya membentuk klasifikasi dan pohon keputusan yang bertujuan untuk membantu tim promosi dalam strategi promosi Madrasah Aliyah Hidayatulloh</p>
              </div>
            </div>
    
        <?php 
          }else if(isset($_GET['pohon_keputusan'])){
        ?>

        <?php
          }else if(isset($_GET['hasil'])){
        ?>

        <?php 
          }
        ?>

      </div>
    </div>
  
  </div>
</div>

</body>
</html>

<?php 

    }
  }
?>