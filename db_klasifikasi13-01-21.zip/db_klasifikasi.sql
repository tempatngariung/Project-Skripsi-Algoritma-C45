-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Jan 2021 pada 17.01
-- Versi server: 10.1.40-MariaDB
-- Versi PHP: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_klasifikasi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_data_latih`
--

CREATE TABLE `tbl_data_latih` (
  `id` bigint(125) NOT NULL,
  `nisn` bigint(125) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(255) NOT NULL,
  `asal_sekolah` varchar(255) NOT NULL,
  `status_sekolah` varchar(255) NOT NULL,
  `kota_asal` varchar(255) NOT NULL,
  `registrasi` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_data_latih`
--

INSERT INTO `tbl_data_latih` (`id`, `nisn`, `nama`, `jenis_kelamin`, `asal_sekolah`, `status_sekolah`, `kota_asal`, `registrasi`) VALUES
(1, 202107001, 'Arya', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(2, 202107002, 'Ahmad Syaifullah', 'laki-laki', 'smp', 'swasta', 'Jakarta', 'Ya'),
(3, 192007001, 'Abdan Sayyidan', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(4, 192007002, 'Agung Kurniawan', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(5, 192007003, 'Al Maududi Amrullah Mubarak', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(6, 192007004, 'Ammar Ahmad Azahary Lubis', 'laki-laki', 'mts', 'negeri', 'Cimahi', 'Ya'),
(7, 192007005, 'Andi Ari Wibowo', 'laki-laki', 'mts', 'negeri', 'Subang', 'Tidak'),
(8, 192007006, 'Azmil Muharram Huda', 'laki-laki', 'mts', 'negeri', 'Garut', 'Ya'),
(9, 192007007, 'Fathurrahman', 'laki-laki', 'smp', 'negeri', 'Garut', 'Ya'),
(10, 192007008, 'Gustian Al Bayhaqi', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(11, 192007009, 'Ilham Dian Aswal', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(12, 192007010, 'M. Aeril Rizki Akbar', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(13, 192007011, 'M.Agil Sofyan', 'laki-laki', 'smp', 'swasta', 'Tasikmalaya', 'Tidak'),
(14, 192007012, 'Windy Latifah', 'perempuan', 'smp', 'swasta', 'Jakarta', 'Ya'),
(15, 192007013, 'Windy Septiawan', 'perempuan', 'smp', 'swasta', 'Bandung', 'Ya'),
(16, 192007014, 'Puja Rahmadanti', 'perempuan', 'smp', 'swasta', 'Bandung', 'Ya'),
(17, 192007015, 'Suci Octaviani', 'perempuan', 'smp', 'swasta', 'Bandung', 'Tidak'),
(18, 192007016, 'Salma Wardatusoffa', 'perempuan', 'smp', 'swasta', 'Bandung', 'Ya'),
(19, 192007017, 'Nurlaela', 'perempuan', 'smp', 'swasta', 'Subang', 'Ya'),
(20, 192007018, 'Susanti', 'perempuan', 'mts', 'swasta', 'Bandung', 'Tidak'),
(21, 192007019, 'Wapiyatul Ahdi Da Silva', 'perempuan', 'mts', 'swasta', 'Bandung', 'Tidak'),
(22, 192007020, 'Indri Nur Azizah', 'perempuan', 'mts', 'swasta', 'Bandung', 'Tidak'),
(23, 192007021, 'Hasna Maulida', 'perempuan', 'smp', 'negeri', 'Subang', 'Tidak'),
(24, 181907001, 'Abdullah Ali Azzam', 'laki-laki', 'mts', 'negeri', 'Subang', 'Tidak'),
(25, 181907002, 'Abdullah Azzam', 'laki-laki', 'mts', 'negeri', 'Garut', 'Ya'),
(26, 181907003, 'Abdurrahman Faiz', 'laki-laki', 'mts', 'negeri', 'Bogor', 'Ya'),
(27, 181907004, 'Afif Ayash', 'perempuan', 'mts', 'negeri', 'Tasikmalaya', 'Ya'),
(28, 181907005, 'Daffa Rizki Al Farisy', 'perempuan', 'mts', 'negeri', 'Tasikmalaya', 'Ya'),
(29, 181907006, 'Ade Fitri Suminar', 'perempuan', 'mts', 'swasta', 'Tasikmalaya', 'Ya'),
(30, 181907007, 'Lilis Rofiqoh', 'perempuan', 'mts', 'swasta', 'Garut', 'Ya'),
(31, 181907008, 'Masna Maulida', 'perempuan', 'mts', 'swasta', 'Bandung', 'Ya'),
(32, 181907009, 'Khoerurijal Rfki Ahmada', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(33, 181907010, 'Lukman Shiddik', 'laki-laki', 'smp', 'swasta', 'Jakarta', 'Ya'),
(34, 181907011, 'Muhammad Cahya Putra R', 'laki-laki', 'smp', 'swasta', 'Garut', 'Ya'),
(35, 181907012, 'Muhammad Fikri Raunaki', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(36, 181907013, 'Muhammad Hidayat', 'laki-laki', 'mts', 'swasta', 'Sumedang', 'Ya'),
(37, 181907014, 'Satria Al Wijaya', 'laki-laki', 'mts', 'swasta', 'Cimahi', 'Ya'),
(38, 181907015, 'Sayahdin', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(39, 171807001, 'Fahmi Ibrahim Usman', 'laki-laki', 'smp', 'swasta', 'Majalengka', 'Tidak'),
(40, 171807002, 'Fajar Muhammad Shidiq', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(41, 171807003, 'Hisyam Muhammad Faqih', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(42, 171807004, 'Ihsan Ramadhani', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(43, 171807005, 'Lukman Ar Rohman', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(44, 171807006, 'Muhammad Azfa Nurul Yaqin', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(45, 171807007, 'Muhammad Imad Aqil', 'laki-laki', 'smp', 'swasta', 'Sumedang', 'Ya'),
(46, 171807008, 'Siti Humairoh', 'perempuan', 'mts', 'swasta', 'Tasikmalaya', 'Tidak'),
(47, 1231252, 'Salsa Bilqis', 'perempuan', 'mts', 'swasta', 'Sumedang', 'Ya'),
(48, 2294029, 'Suci Rahmandanti', 'perempuan', 'mts', 'swasta', 'Bandung', 'Ya'),
(49, 41140781, 'Nur Fatimah', 'perempuan', 'mts', 'swasta', 'Bandung', 'Ya'),
(50, 37945438, 'Siska Maulida', 'perempuan', 'mts', 'swasta', 'Subang', 'Ya'),
(51, 33225982, 'Ulfah Nur Azizah', 'perempuan', 'mts', 'swasta', 'Bandung', 'Ya'),
(52, 56634352, 'Insan Muhammad Hanif', 'laki-laki', 'mts', 'swasta', 'Cimahi', 'Ya'),
(53, 60304023, 'M. Aeril Rizki Akbar', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(54, 35233619, 'Muhammad Agil Sofyan', 'laki-laki', 'mts', 'swasta', 'Tasikmalaya', 'Ya'),
(55, 43532553, 'Muhammad Amrullah Algozy Chaf', 'laki-laki', 'mts', 'swasta', 'Sumedang', 'Ya'),
(56, 43534563, 'Muhamad Fahru Roji', 'laki-laki', 'smp', 'swasta', 'Majalengka', 'Ya'),
(57, 66994549, 'Muhammad Ferris Eriyanto', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(58, 95405849, 'Muhammad Fikri Abdillah', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(59, 45654699, 'Muhammad Izzul Haq', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(60, 31261057, 'M. Jafar Aly Ashodiq', 'laki-laki', 'smp', 'negeri', 'Bogor', 'Ya'),
(61, 23224384, 'Muhammad Kairy Abdullah Dzaky', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(62, 43272963, 'Muhammad Makmur Billah', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(63, 47020096, 'Muhammad Miqdad Jundulloh', 'laki-laki', 'smp', 'negeri', 'Subang', 'Ya'),
(64, 36047107, 'Muhammad Nabil Makarim', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(65, 41361132, 'Muhammad Rijal Kafilah Syuhada', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Tidak'),
(66, 41688259, 'Nabil Fikri Kenamon', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Tidak'),
(67, 11232333, 'Nandi Nur Ikhsan', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Tidak'),
(68, 44245222, 'Qushai Dhia Majid', 'laki-laki', 'smp', 'swasta', 'Cimahi', 'Ya'),
(69, 42260685, 'R. Muhammad Jourdy Falkan Firdaus', 'laki-laki', 'smp', 'swasta', 'Sumedang', 'Ya'),
(70, 34006882, 'Rahmat Ardiansyah', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(71, 41859562, 'Umar Azmi', 'laki-laki', 'smp', 'swasta', 'Bogor', 'Ya'),
(72, 38511286, 'Wapiyatul Ahdi Dasilva', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(73, 34929333, 'Zamal Arip', 'laki-laki', 'smp', 'swasta', 'Garut', 'Ya'),
(74, 32798592, 'Abdullah Ali Azzam', 'laki-laki', 'smp', 'swasta', 'Subang', 'Ya'),
(75, 98883234, 'Abdurahman Faiz', 'laki-laki', 'smp', 'swasta', 'Bogor', 'Ya'),
(76, 77334234, 'Abdurrahman Azfa Naufal', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(77, 23423331, 'Afif Ayash', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(78, 28494513, 'Dedi Ramli', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(79, 37732084, 'Hijran Annur Ghourof Furi', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(80, 27012296, 'Khoerurizal Rifqy Achmada', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(81, 32534013, 'Lukman Shiddiq', 'laki-laki', 'smp', 'swasta', 'Jakarta', 'Ya'),
(82, 67273000, 'M. Fikri Raunaqi', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(83, 35868358, 'Marup Salim', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(84, 20023122, 'Muhammad Haqqul Yaqin Nursilmi', 'laki-laki', 'smp', 'swasta', 'Subang', 'Ya'),
(85, 21059370, 'Muhammad Ammar Baharudin Hariz', 'laki-laki', 'mts', 'swasta', 'Cimahi', 'Ya'),
(86, 45322223, 'Muhammad Aqdam Nasrulloh', 'laki-laki', 'mts', 'swasta', 'Tasikmalaya', 'Ya'),
(87, 1231255, 'Muhammad Fajrul Islam', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(88, 12123441, 'Muhammad Firmansyah', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Tidak'),
(89, 54521322, 'Muhammad Idzhar Robbani', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Tidak'),
(90, 82994213, 'Muhammad Lutfan Hudhaifa', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Tidak'),
(91, 34216488, 'Muhmmad Ridho Fathoni', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(92, 32530260, 'Nur Halim Majid', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Tidak'),
(93, 23421124, 'Salman Ghifary Ramadhan', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Tidak'),
(94, 34075217, 'Sayahdin', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(95, 26714848, 'Wildan Muyassar', 'laki-laki', 'mts', 'swasta', 'Tasikmalaya', 'Ya'),
(96, 88237341, 'Anif Abdurrohman', 'laki-laki', 'mts', 'swasta', 'Sukabumi', 'Ya'),
(97, 91002010, 'Arjun Nabil Al-Muflih Caf', 'laki-laki', 'mts', 'swasta', 'Cimahi', 'Ya'),
(98, 73357360, 'Haikal Fajar Abdillah', 'laki-laki', 'mts', 'swasta', 'Majalengka', 'Ya'),
(99, 32523132, 'M. Hafizh Yusuf', 'laki-laki', 'mts', 'swasta', 'Subang', 'Ya'),
(100, 23499998, 'M. Imad Aqil', 'laki-laki', 'mts', 'swasta', 'Sumedang', 'Ya'),
(101, 75454342, 'Mizanul Muluk Nur Sulus', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(102, 20766998, 'Muhammad Azfa Nurul Yaqin', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(103, 19712894, 'M. Kholid Fathurrahman', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(104, 87364234, 'M. Nabhan Taqiyuddin', 'laki-laki', 'smp', 'negeri', 'Tasikmalaya', 'Ya'),
(105, 15715594, 'M. Nabil Abduh Nashir', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(106, 22012079, 'Ricky Nurul Ilham', 'laki-laki', 'smp', 'negeri', 'Jakarta', 'Ya'),
(107, 23492341, 'Fajar Muhammad Sidiq', 'laki-laki', 'smp', 'negeri', 'Bandung', 'Ya'),
(108, 93334521, 'Yuan Salsabila Arrosyid', 'laki-laki', 'smp', 'negeri', 'Garut', 'Ya'),
(109, 20517672, 'Muhamad Dhulfiqar Adnan', 'laki-laki', 'smp', 'negeri', 'Subang', 'Ya'),
(110, 8213172300, 'Agus Yusuf al-Gozali', 'laki-laki', 'smp', 'swasta', 'Tasikmalaya', 'Ya'),
(111, 2233341231, 'Akmal Dinul Islam', 'laki-laki', 'smp', 'swasta', 'Tasikmalaya', 'Ya'),
(112, 8882212000, 'Ali Imron', 'laki-laki', 'mts', 'swasta', 'Garut', 'Ya'),
(113, 4568414, 'Deni Mulyawan', 'laki-laki', 'smp', 'swasta', 'Sumedang', 'Ya'),
(114, 1112345, 'Didin Wahyudin', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(115, 24888203, 'Dimas Syahru Ramadhan', 'laki-laki', 'smp', 'swasta', 'Cimahi', 'Ya'),
(116, 34222883, 'Habib Anand', 'laki-laki', 'smp', 'swasta', 'Sukabumi', 'Ya'),
(117, 773341992, 'Hadi', 'laki-laki', 'smp', 'swasta', 'Sukabumi', 'Ya'),
(118, 9882900, 'Ibnu Khan Fatah Enting', 'laki-laki', 'smp', 'swasta', 'Subang', 'Ya'),
(119, 18376050, 'Mufakkirul Umam', 'laki-laki', 'smp', 'negeri', 'Jakarta', 'Ya'),
(120, 9900231112, 'Muhammad Azka Eriyanto ', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(121, 7309769, 'Moh Dafa` El Huda', 'laki-laki', 'mts', 'swasta', 'Sukabumi', 'Ya'),
(122, 8882733112, 'M. Denaneer Ali Rahman', 'laki-laki', 'smp', 'swasta', 'Bogor', 'Tidak'),
(123, 9933200344, 'Muhammad Fauzan Hadiansyah', 'laki-laki', 'mts', 'swasta', 'Bogor', 'Tidak'),
(124, 4334119, 'Muhammad Nauval Abdillah Jaelani', 'laki-laki', 'mts', 'swasta', 'Bogor', 'Tidak'),
(125, 9374112, 'Naufal Muyassar Tsany', 'laki-laki', 'mts', 'swasta', 'Garut', 'Ya'),
(126, 10341737, 'Nur Izzah Muhammad Ilyas', 'laki-laki', 'mts', 'swasta', 'Sukabumi', 'Ya'),
(127, 93423412, 'Rafli Prasetyo', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(128, 9934324900, 'Rasyid Abdan Syakur', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(129, 34444323, 'Rido Illahi Solin', 'laki-laki', 'mts', 'swasta', 'Sukabumi', 'Ya'),
(130, 41938811, 'Sa`ad Abdullah', 'laki-laki', 'mts', 'swasta', 'Sukabumi', 'Ya'),
(131, 34444322, 'Zaki Rasyid Pamungkas', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Tidak'),
(132, 8377342123, 'Ahmad Fauzan Rifai', 'laki-laki', 'mts', 'swasta', 'Majalengka', 'Ya'),
(133, 80903003, 'Aldi Alamsyah', 'laki-laki', 'mts', 'swasta', 'Bogor', 'Ya'),
(134, 9033300022, 'Amin Rosidin', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(135, 9977165225, 'Kamaludin Putra', 'laki-laki', 'mts', 'swasta', 'Bandung', 'Ya'),
(136, 2968452, 'Muhammad Yahya Ayasy', 'laki-laki', 'smp', 'swasta', 'Jakarta', 'Ya'),
(137, 931105, 'Mulky Mochammad Rizal', 'laki-laki', 'smp', 'swasta', 'Bandung', 'Ya'),
(138, 9923423412, 'Nasrul Faudzil Adhim', 'laki-laki', 'smp', 'swasta', 'Majalengka', 'Ya'),
(139, 21312321, 'Nur Mahmud Yusuf', 'laki-laki', 'smp', 'swasta', 'Majalengka', 'Ya'),
(140, 9993423413, 'Abdul Rozak', 'laki-laki', 'smp', 'swasta', 'Majalengka', 'Tidak'),
(141, 9997872512, 'Wardatusoffa', 'perempuan', 'smp', 'swasta', 'Cimahi', 'Ya'),
(142, 9995837791, 'Ai Latifah', 'perempuan', 'smp', 'swasta', 'Garut', 'Ya'),
(143, 9981576078, 'Intan Multia', 'perempuan', 'smp', 'swasta', 'Tasikmalaya', 'Ya'),
(144, 8842111233, 'Lita Angreani', 'perempuan', 'smp', 'swasta', 'Sukabumi', 'Ya'),
(145, 10033995, 'Muhammad Haris Harahap', 'laki-laki', 'smp', 'swasta', 'Sukabumi', 'Ya'),
(146, 9996979984, 'Muhammad Nashirul Hak', 'laki-laki', 'smp', 'swasta', 'Garut', 'Ya'),
(147, 9994818901, 'Muhammad Syauqi Al Ghifari', 'laki-laki', 'smp', 'swasta', 'Majalengka', 'Tidak'),
(148, 9981713749, 'Rifki Fuad Irawan', 'laki-laki', 'smp', 'swasta', 'Bogor', 'Tidak'),
(149, 8832421998, 'Rini Susilawati', 'perempuan', 'mts', 'swasta', 'Bogor', 'Ya');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(125) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `level`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(2, 'kepsek', '8561863b55faf85b9ad67c52b3b851ac', 'kepsek');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_data_latih`
--
ALTER TABLE `tbl_data_latih`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_data_latih`
--
ALTER TABLE `tbl_data_latih`
  MODIFY `id` bigint(125) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(125) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
